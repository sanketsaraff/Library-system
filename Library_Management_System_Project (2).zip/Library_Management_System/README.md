# Library Management System — Web Development Minor Project

## 1. Project overview
A browser-based Library Management System built using **HTML, CSS and JavaScript**. It demonstrates CRUD (Create, Read, Update and Delete) operations for book records and includes basic book issue/return tracking.

## 2. Features
- Add a book with title, author, ISBN, category, publisher, year and quantity.
- View the book catalog in a table.
- Search by title, author, ISBN, publisher or category.
- Filter by category and availability.
- Edit and delete book records.
- Issue an available book to a borrower and return it.
- Dashboard counts for titles, available copies, issued copies and categories.
- Recent activity log.
- Responsive layout for desktop and mobile.
- Saves data in browser LocalStorage; no server or database installation is needed.

## 3. Technologies
- HTML5: page structure and forms.
- CSS3: responsive layout and visual styling.
- JavaScript: CRUD operations, validation, search, issue/return and rendering.
- LocalStorage: persistent storage in the current browser.

## 4. How to run
1. Extract the ZIP file.
2. Open the `Library_Management_System` folder.
3. Double-click `index.html`, or open the folder in Visual Studio Code and use Live Server.
4. The application opens in a modern browser. No internet connection is needed for the core functionality (Google Fonts are optional).
5. Use **Add a book** to create a record. Try search, edit, issue, return and delete.

## 5. Data storage
Book records and activity history are saved in LocalStorage under:
- `libradesk_books_v1`
- `libradesk_activity_v1`

Data is stored only in the browser and device where the project is opened. Clearing browser site data may remove it. This is a front-end demonstration, not a multi-user online database.

## 6. CRUD mapping
| CRUD operation | Implementation |
|---|---|
| Create | Add a book using the form |
| Read | Display catalog and dashboard statistics |
| Update | Edit book details |
| Delete | Delete a selected book after confirmation |

## 7. Validation
- Required fields: title, author, category and quantity.
- Quantity must be a positive integer.
- ISBN must be unique when supplied.
- Publication year must be between 1000 and 2100 when supplied.
- An issued book cannot be issued again until it is returned.

## 8. Suggested future enhancements
- Backend database (MySQL / MongoDB).
- User login and librarian/student roles.
- Due dates, overdue alerts and fine calculation.
- Multiple copies and separate issue records per copy.
- Export catalog to CSV/PDF.

## 9. Project structure
```
Library_Management_System/
├── index.html
├── style.css
├── script.js
├── README.md
└── Project_Report.docx
```
