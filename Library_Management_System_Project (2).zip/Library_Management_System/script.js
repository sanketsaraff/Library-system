const STORAGE_KEY = "libradesk_books_v1";
const ACTIVITY_KEY = "libradesk_activity_v1";
const $ = (id) => document.getElementById(id);

let books = load(STORAGE_KEY, []);
let activities = load(ACTIVITY_KEY, []);

function load(key, fallback) {
  try { const value = JSON.parse(localStorage.getItem(key)); return Array.isArray(value) ? value : fallback; }
  catch { return fallback; }
}
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
  localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activities.slice(0, 12)));
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
function addActivity(message, symbol = "✓") {
  activities.unshift({ message, symbol, time: new Date().toLocaleString() });
  save(); renderActivity();
}
function status(book) { return book.issuedTo ? "Issued" : "Available"; }

function render() {
  const total = books.reduce((sum, b) => sum + Number(b.quantity), 0);
  const issued = books.filter(b => b.issuedTo).length;
  $("totalBooks").textContent = books.length;
  $("availableBooks").textContent = total - issued;
  $("issuedBooks").textContent = issued;
  $("categoryCount").textContent = new Set(books.map(b => b.category.trim().toLowerCase()).filter(Boolean)).size;
  $("recordCount").textContent = `${books.length} record${books.length === 1 ? "" : "s"}`;
  renderCategories();
  renderTable();
  renderActivity();
}
function renderCategories() {
  const select = $("categoryFilter"), selected = select.value;
  const categories = [...new Set(books.map(b => b.category).filter(Boolean))].sort();
  select.innerHTML = '<option value="">All categories</option>' + categories.map(c => `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
  select.value = categories.includes(selected) ? selected : "";
}
function renderTable() {
  const query = $("searchInput").value.trim().toLowerCase();
  const category = $("categoryFilter").value;
  const state = $("statusFilter").value;
  const filtered = books.filter(b => {
    const matches = [b.title,b.author,b.isbn,b.publisher,b.category].join(" ").toLowerCase().includes(query);
    return matches && (!category || b.category === category) && (!state || status(b) === state);
  });
  $("bookTableBody").innerHTML = filtered.map(b => {
    const issued = Boolean(b.issuedTo);
    return `<tr>
      <td><div class="book-cell"><div class="book-cover">${escapeHTML((b.title || "B").charAt(0).toUpperCase())}</div><div><div class="book-title">${escapeHTML(b.title)}</div><div class="book-author">by ${escapeHTML(b.author)}</div></div></div></td>
      <td>${escapeHTML(b.isbn || "—")}</td><td><span class="category-pill">${escapeHTML(b.category)}</span></td>
      <td>${Number(b.quantity)}</td><td><span class="status-pill ${issued ? "issued" : "available"}">${issued ? "Issued" : "Available"}</span></td>
      <td><div class="actions">${issued
        ? `<button class="action-btn" data-action="return" data-id="${b.id}">Return</button>`
        : `<button class="action-btn" data-action="issue" data-id="${b.id}">Issue</button>`}
        <button class="action-btn" data-action="edit" data-id="${b.id}">Edit</button>
        <button class="action-btn danger" data-action="delete" data-id="${b.id}">Delete</button></div></td>
    </tr>`;
  }).join("");
  $("emptyState").hidden = filtered.length > 0;
  $("bookTableBody").parentElement.style.display = filtered.length ? "" : "none";
}
function renderActivity() {
  $("activityList").innerHTML = activities.length ? activities.slice(0,6).map(a =>
    `<div class="activity-item"><div class="activity-dot">${escapeHTML(a.symbol)}</div><div class="activity-text">${escapeHTML(a.message)}</div><div class="activity-time">${escapeHTML(a.time)}</div></div>`
  ).join("") : '<p class="muted">No activity yet. Add or issue a book to see updates here.</p>';
}
function openBookDialog(book = null) {
  $("bookForm").reset();
  $("bookId").value = book?.id || "";
  $("dialogTitle").textContent = book ? "Edit book details" : "Add a book";
  $("title").value = book?.title || "";
  $("author").value = book?.author || "";
  $("isbn").value = book?.isbn || "";
  $("category").value = book?.category || "";
  $("publisher").value = book?.publisher || "";
  $("year").value = book?.year || "";
  $("quantity").value = book?.quantity || 1;
  $("quantity").disabled = Boolean(book?.issuedTo);
  $("bookDialog").showModal();
}
function closeBookDialog() { $("bookDialog").close(); }
function openIssueDialog(book) {
  $("issueForm").reset(); $("issueBookId").value = book.id;
  $("issueBookName").textContent = `${book.title} — ${book.author}`;
  $("issueDialog").showModal();
}
function validYear(year) { return !year || (Number(year) >= 1000 && Number(year) <= 2100); }

$("addBookTop").addEventListener("click", () => openBookDialog());
$("emptyAddBtn").addEventListener("click", () => openBookDialog());
$("closeDialog").addEventListener("click", closeBookDialog);
$("cancelDialog").addEventListener("click", closeBookDialog);
$("closeIssueDialog").addEventListener("click", () => $("issueDialog").close());
$("cancelIssue").addEventListener("click", () => $("issueDialog").close());

$("bookForm").addEventListener("submit", e => {
  e.preventDefault();
  const id = $("bookId").value;
  const data = {
    title: $("title").value.trim(), author: $("author").value.trim(),
    isbn: $("isbn").value.trim(), category: $("category").value.trim(),
    publisher: $("publisher").value.trim(), year: $("year").value,
    quantity: Number($("quantity").value)
  };
  if (!validYear(data.year)) return toast("Enter a valid publication year.");
  if (!Number.isInteger(data.quantity) || data.quantity < 1) return toast("Quantity must be at least 1.");
  const duplicate = data.isbn && books.some(b => b.isbn.toLowerCase() === data.isbn.toLowerCase() && b.id !== id);
  if (duplicate) return toast("A book with this ISBN already exists.");
  if (id) {
    const index = books.findIndex(b => b.id === id);
    if (index < 0) return toast("Book record not found.");
    books[index] = { ...books[index], ...data };
    addActivity(`Updated details for <strong>${escapeHTML(data.title)}</strong>`, "✎");
    toast("Book updated successfully.");
  } else {
    books.unshift({ id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())), ...data, issuedTo: null });
    addActivity(`Added <strong>${escapeHTML(data.title)}</strong> to the catalog`, "+");
    toast("Book added successfully.");
  }
  save(); closeBookDialog(); render();
});
$("issueForm").addEventListener("submit", e => {
  e.preventDefault();
  const book = books.find(b => b.id === $("issueBookId").value);
  if (!book || book.issuedTo) return toast("This book is not available.");
  const borrower = $("borrower").value.trim();
  if (!borrower) return toast("Enter the borrower's name.");
  book.issuedTo = { name: borrower, id: $("borrowerId").value.trim(), date: new Date().toISOString() };
  save(); $("issueDialog").close(); addActivity(`<strong>${escapeHTML(book.title)}</strong> issued to ${escapeHTML(borrower)}`, "↗");
  render(); toast("Book issued successfully.");
});
$("bookTableBody").addEventListener("click", e => {
  const button = e.target.closest("button[data-action]"); if (!button) return;
  const book = books.find(b => b.id === button.dataset.id); if (!book) return;
  const action = button.dataset.action;
  if (action === "edit") openBookDialog(book);
  if (action === "issue") openIssueDialog(book);
  if (action === "return") {
    const borrower = book.issuedTo.name; book.issuedTo = null; save();
    addActivity(`<strong>${escapeHTML(book.title)}</strong> returned by ${escapeHTML(borrower)}`, "↙");
    render(); toast("Book returned successfully.");
  }
  if (action === "delete") {
    if (!confirm(`Delete "${book.title}" from the catalog? This cannot be undone.`)) return;
    books = books.filter(b => b.id !== book.id); save();
    addActivity(`Deleted <strong>${escapeHTML(book.title)}</strong> from the catalog`, "−");
    render(); toast("Book deleted.");
  }
});
["searchInput","categoryFilter","statusFilter"].forEach(id => $(id).addEventListener(id === "searchInput" ? "input" : "change", renderTable));

// Add starter records only on the first launch; users can edit or delete them.
if (!localStorage.getItem(STORAGE_KEY)) {
  books = [
    {id:"demo-1",title:"The Alchemist",author:"Paulo Coelho",isbn:"9780061122415",category:"Fiction",publisher:"HarperOne",year:"1988",quantity:4,issuedTo:null},
    {id:"demo-2",title:"Clean Code",author:"Robert C. Martin",isbn:"9780132350884",category:"Technology",publisher:"Prentice Hall",year:"2008",quantity:3,issuedTo:null},
    {id:"demo-3",title:"Wings of Fire",author:"A. P. J. Abdul Kalam",isbn:"9788173711466",category:"Biography",publisher:"Universities Press",year:"1999",quantity:2,issuedTo:{name:"Demo Student",id:"DEMO01",date:new Date().toISOString()}}
  ];
  save();
}
render();
